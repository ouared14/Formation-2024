#! /bin/bash
mongoimport --host mongo-db --db unibench --authenticationDatabase admin --username mongoUser --password mongoPassword --collection Order --type json '/mongo-data/Order.json'